"""lavatune package."""

__all__ = ["__version__"]

__version__ = "0.0.2a"
