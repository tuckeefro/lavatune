"""Environment diagnostics for failures that happen before the TUI can start."""

from __future__ import annotations

import curses
import os
import platform
import shutil
import sys
import time
from dataclasses import dataclass
from typing import Callable

from .audio import CAPTURE_BINARIES, AudioCapture
from .config import AppConfig
from .text import sanitize_display_text


@dataclass(slots=True, frozen=True)
class DoctorCheck:
    name: str
    status: str
    detail: str
    remedy: str = ""


@dataclass(slots=True, frozen=True)
class DoctorReport:
    checks: tuple[DoctorCheck, ...]

    @property
    def errors(self) -> int:
        return sum(check.status == "error" for check in self.checks)

    @property
    def warnings(self) -> int:
        return sum(check.status == "warn" for check in self.checks)

    @property
    def exit_code(self) -> int:
        return 1 if self.errors else 0


def _terminal_color_count() -> int:
    try:
        curses.setupterm(term=os.environ.get("TERM") or None)
        return max(0, curses.tigetnum("colors"))
    except (curses.error, OSError):
        return 0


def _backend_check(config: AppConfig) -> tuple[DoctorCheck, str | None]:
    if platform.system() == "Darwin" and config.audio.capture_route == "system":
        available = [
            backend
            for backend in ("ffmpeg", "sox")
            if backend in CAPTURE_BINARIES and shutil.which(CAPTURE_BINARIES[backend]) is not None
        ]
        return (
            DoctorCheck(
                "audio backend",
                "warn",
                "live system audio output capture is not supported on macOS in the Python companion"
                + (f"; available capture tools for microphone: {', '.join(available)}" if available else ""),
                "Use --demo for synthetic audio or set listening context to microphone.",
            ),
            available[0] if available else None,
        )

    valid_backends = (
        ("ffmpeg", "sox")
        if platform.system() == "Darwin"
        else ("pipewire", "pulse", "ffmpeg")
        if config.audio.capture_route == "system"
        else ("pipewire", "pulse", "ffmpeg", "sox")
    )
    available = [
        backend
        for backend in valid_backends
        if shutil.which(CAPTURE_BINARIES[backend]) is not None
    ]
    preferred = config.audio.backend
    if preferred != "auto" and preferred not in available:
        binary = CAPTURE_BINARIES.get(preferred, preferred)
        if preferred in CAPTURE_BINARIES and shutil.which(CAPTURE_BINARIES[preferred]) is not None:
            return (
                DoctorCheck(
                    "audio backend",
                    "error",
                    f"requested backend '{preferred}' is available but does not support {config.audio.capture_route} capture",
                    "Choose another backend or switch listening context.",
                ),
                None,
            )
        return (
            DoctorCheck(
                "audio backend",
                "error",
                f"requested {preferred}; {binary} was not found",
                "Install the backend program or choose --backend auto.",
            ),
            None,
        )
    if not available:
        remedy = (
            "Install ffmpeg or sox for microphone capture."
            if platform.system() == "Darwin"
            else "Install pw-cat, parec, or ffmpeg."
        )
        return (
            DoctorCheck(
                "audio backend",
                "error",
                "no supported capture program found",
                remedy,
            ),
            None,
        )
    selected = preferred if preferred != "auto" else available[0]
    return (
        DoctorCheck(
            "audio backend",
            "ok",
            f"selected {selected}; available {', '.join(available)}",
        ),
        selected,
    )


def _probe_audio(
    config: AppConfig,
    *,
    timeout: float,
    capture_factory: Callable[..., AudioCapture],
) -> DoctorCheck:
    capture: AudioCapture | None = None
    try:
        capture = capture_factory(config.audio)
        capture.start()
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if capture.frames_received() > 0:
                frame = capture.latest()
                return DoctorCheck(
                    "audio frames",
                    "ok",
                    f"received PCM through {capture.status()} (level {frame.rms:0.3f})",
                )
            if capture.error():
                return DoctorCheck(
                    "audio frames",
                    "error",
                    capture.error() or "capture stopped",
                    "Run wpctl status or pactl list short sources, then pass --source explicitly.",
                )
            time.sleep(0.05)
        return DoctorCheck(
            "audio frames",
            "error",
            f"no PCM arrived within {timeout:0.1f}s",
            "Play audio, verify the monitor source, or try another --backend.",
        )
    except (OSError, RuntimeError) as exc:
        return DoctorCheck(
            "audio frames",
            "error",
            sanitize_display_text(str(exc), max_chars=500),
            "Check the selected backend and monitor source.",
        )
    finally:
        if capture is not None:
            capture.stop()


def inspect_environment(
    config: AppConfig,
    *,
    probe_audio: bool = True,
    probe_timeout: float = 1.5,
    capture_factory: Callable[..., AudioCapture] = AudioCapture,
) -> DoctorReport:
    checks: list[DoctorCheck] = []
    current_os = platform.system()
    supported_os = current_os in {"Linux", "Darwin"}
    checks.append(
        DoctorCheck(
            "platform",
            "ok" if supported_os else "error",
            f"{current_os} {platform.machine()}".strip(),
            "Lavatune supports Linux and macOS." if not supported_os else "",
        )
    )

    supported_python = sys.version_info >= (3, 11)
    checks.append(
        DoctorCheck(
            "python",
            "ok" if supported_python else "error",
            platform.python_version(),
            "Install Python 3.11 or newer." if not supported_python else "",
        )
    )

    colors = _terminal_color_count()
    checks.append(
        DoctorCheck(
            "terminal colors",
            "ok" if colors >= 256 else "warn",
            f"{colors} colors reported",
            "Use a 256-color terminal for the intended palette." if colors < 256 else "",
        )
    )

    backend, selected_backend = _backend_check(config)
    checks.append(backend)

    playerctl = shutil.which("playerctl")
    checks.append(
        DoctorCheck(
            "media metadata",
            "ok" if playerctl else "warn",
            "playerctl available" if playerctl else "playerctl not found; titles will be hidden",
            "Install playerctl only if local media titles are wanted." if not playerctl else "",
        )
    )

    if probe_audio and selected_backend is not None and supported_os:
        checks.append(
            _probe_audio(
                config,
                timeout=max(0.2, min(5.0, probe_timeout)),
                capture_factory=capture_factory,
            )
        )
    elif probe_audio:
        checks.append(
            DoctorCheck(
                "audio frames",
                "skip",
                f"audio probe is not supported on {current_os}",
                "Use --demo or run on Linux/macOS.",
            )
        )
    elif not probe_audio:
        checks.append(DoctorCheck("audio frames", "skip", "live probe disabled"))

    return DoctorReport(tuple(checks))


def format_report(report: DoctorReport) -> str:
    lines = ["Lavatune doctor", ""]
    for check in report.checks:
        detail = sanitize_display_text(check.detail, max_chars=500)
        lines.append(f"[{check.status:5}] {check.name}: {detail}")
        if check.remedy:
            lines.append(f"        {check.remedy}")
    lines.extend(
        [
            "",
            f"Result: {report.errors} error(s), {report.warnings} warning(s)",
        ]
    )
    return "\n".join(lines)
